import requests
from bs4 import BeautifulSoup
import smtplib

URL="https://www.flipkart.com/vivo-z1pro-sonic-black-64-gb/p/itmfghyebfrvjzfs?pid=MOBFHHT56NTTZKZ5&lid=LSTMOBFHHT56NTTZKZ5PWUNSS&fm=neo%2Fmerchandising&iid=M_20a63b73-cf2e-470d-b180-ba56fbac4b13_8.BMV9BI6Q0PKK&ssid=tegu40bw2o0000001583067025968&otracker=hp_omu_Best%2Bselling%2BPhones_4_9.dealCard.OMU_Best%2Bselling%2BPhones_BMV9BI6Q0PKK_6&otracker1=hp_omu_WHITELISTED_neo%2Fmerchandising_Best%2Bselling%2BPhones_NA_dealCard_cc_4_NA_view-all_6&cid=BMV9BI6Q0PKK"

headers={"User-Agent":'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36'}

def PriceFinder():   
  page=requests.get(URL,headers=headers)
  soup= BeautifulSoup(page.content,'html.parser')
  theitem=soup.find("span",{"class":"_35KyD6"}).text
  theprice=soup.find("div",{"class":"_1vC4OE _3qQ9m1"}).text
  price=int(theprice[1:3]+theprice[4:7])
  if(price<1200):
    send_mail()
  print(theitem)
  print(price)
def send_mail():
  s = smtplib.SMTP('smtp.gmail.com', 587)
  s.starttls()
  s.login("nikitanayak330@gmail.com", "sender_email_id_password")
  message = "Price dropped"
  s.sendmail("nikitanayak330@gmail.com", "nikita330nayak@gmail.com", message)
  s.quit()

if __name__=="__main__":
  PriceFinder()


